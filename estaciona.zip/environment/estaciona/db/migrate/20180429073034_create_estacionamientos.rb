class CreateEstacionamientos < ActiveRecord::Migration[5.2]
  def change
    create_table :estacionamientos do |t|
      t.string :nombre
      t.string :direc
      t.string :distrito
      t.string :tfijo
      t.string :pphora
      t.string :altura
      t.string :longitud
      t.string :ancho
      t.string :tipo
      t.string :ubicacion

      t.timestamps
    end
  end
end
