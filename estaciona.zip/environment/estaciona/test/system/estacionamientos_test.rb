require "application_system_test_case"

class EstacionamientosTest < ApplicationSystemTestCase
  setup do
    @estacionamiento = estacionamientos(:one)
  end

  test "visiting the index" do
    visit estacionamientos_url
    assert_selector "h1", text: "Estacionamientos"
  end

  test "creating a Estacionamiento" do
    visit estacionamientos_url
    click_on "New Estacionamiento"

    fill_in "Altura", with: @estacionamiento.altura
    fill_in "Ancho", with: @estacionamiento.ancho
    fill_in "Direc", with: @estacionamiento.direc
    fill_in "Distrito", with: @estacionamiento.distrito
    fill_in "Longitud", with: @estacionamiento.longitud
    fill_in "Nombre", with: @estacionamiento.nombre
    fill_in "Pphora", with: @estacionamiento.pphora
    fill_in "Tfijo", with: @estacionamiento.tfijo
    fill_in "Tipo", with: @estacionamiento.tipo
    fill_in "Ubicacion", with: @estacionamiento.ubicacion
    click_on "Create Estacionamiento"

    assert_text "Estacionamiento was successfully created"
    click_on "Back"
  end

  test "updating a Estacionamiento" do
    visit estacionamientos_url
    click_on "Edit", match: :first

    fill_in "Altura", with: @estacionamiento.altura
    fill_in "Ancho", with: @estacionamiento.ancho
    fill_in "Direc", with: @estacionamiento.direc
    fill_in "Distrito", with: @estacionamiento.distrito
    fill_in "Longitud", with: @estacionamiento.longitud
    fill_in "Nombre", with: @estacionamiento.nombre
    fill_in "Pphora", with: @estacionamiento.pphora
    fill_in "Tfijo", with: @estacionamiento.tfijo
    fill_in "Tipo", with: @estacionamiento.tipo
    fill_in "Ubicacion", with: @estacionamiento.ubicacion
    click_on "Update Estacionamiento"

    assert_text "Estacionamiento was successfully updated"
    click_on "Back"
  end

  test "destroying a Estacionamiento" do
    visit estacionamientos_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Estacionamiento was successfully destroyed"
  end
end
