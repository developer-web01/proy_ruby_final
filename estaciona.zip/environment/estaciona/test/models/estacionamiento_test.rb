require 'test_helper'

class EstacionamientoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
