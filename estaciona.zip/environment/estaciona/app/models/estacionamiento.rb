class Estacionamiento < ApplicationRecord
end
